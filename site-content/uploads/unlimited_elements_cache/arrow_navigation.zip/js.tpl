jQuery(document).ready(function(){
  
    var objRemoteApi = new UERemoteWidgets();
  
    function initArrows(parentid2){
	
        var options = {};
      
        if(parentid2)
      		options.force_parentid = parentid2;
          
        objRemoteApi.onWidgetInit("{{uc_id}}",function(objWidget){

            {% if show_next == "true" %}
            objRemoteApi.setAction("next", ".ue-carousel-next");
             {% endif %}

             {% if show_previous == "true" %}
              objRemoteApi.setAction("prev", ".ue-carousel-prev");
              {% endif %}		

        },options);	
     
        
    }
    
    initArrows();
    
    var objWidget = jQuery("#{{uc_id}}");
    
     var parentid2 = objWidget.data("parentid2");
     if(parentid2)
    	initArrows(parentid2);   
              
     
     {% if set_disable_on_first_last == "true" %}     
     	
       var objPrevArrow = objWidget.find('.ue-carousel-prev');
       var objNextArrow = objWidget.find('.ue-carousel-next');
       var objArrows = objWidget.find('.ue-remote-arrow');

       var classDisabled = 'uc-disabled';
     
       /*
       * set disable on first / last option  
       */    
       function setDisableOnFirstLast(){
       
       		var currentNum = objRemoteApi.doAction('get_num_current');
            var totalNum = objRemoteApi.doAction('get_total_items');

            if(currentNum == 0 && objPrevArrow.length == 1)
                objPrevArrow.addClass(classDisabled);
            else if(currentNum == (totalNum - 1) && objNextArrow.length == 1)
                objNextArrow.addClass(classDisabled);
            else  
                objArrows.removeClass(classDisabled);
       
       }      
       
       setTimeout(function(){
         
          //set disable on init
          setDisableOnFirstLast();
         
          //set disable on change
          objRemoteApi.onEvent("change", setDisableOnFirstLast);

       },200);  
       
     {% endif %}	                  
       	          
});