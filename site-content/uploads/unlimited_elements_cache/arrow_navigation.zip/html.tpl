<div class="ue-remote-carousel-navigation-wrapper">
<div id="{{uc_id}}" class="ue-remote-carousel-navigation" {{remote.attributes|raw}}>
  
  
  
{% if show_previous == "true" %}
	<div class="ue-remote-arrow ue-carousel-prev {{hover_animation}}">
    <div class="ue-carousel-nav-icon">{{previous_icon_html|raw}}</div>
    {% if show_labels == "true" %}
        <div class="ue-carousel-nav-label">{{previous_label|raw}}</div>
    {% endif %}	
  </div>   
{% endif %}	

  
 

{% if show_next == "true" %}
  <div class="ue-remote-arrow ue-carousel-next {{hover_animation}}">
    {% if show_labels == "true" %}
    <div class="ue-carousel-nav-label">{{next_label|raw}}</div>
    {% endif %}
    <div class="ue-carousel-nav-icon">{{next_icon_html|raw}}</div>
  </div>
{% endif %}
  
  
</div>
</div>