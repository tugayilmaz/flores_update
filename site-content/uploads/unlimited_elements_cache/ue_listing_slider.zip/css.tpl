#{{uc_id}}{
  min-height:1px;
}

#{{uc_id}} *{
	box-sizing: border-box;
}

#{{uc_id}} .owl-nav .owl-prev{
    position:absolute;
    left:{{nav_arrow_spacing}}px;
    display:inline-block;
    text-align:center;
    transition:1s;
}
#{{uc_id}} .owl-nav .owl-next{
  position:absolute;
    right:{{nav_arrow_spacing}}px;
  display:inline-block;
  text-align:center;
  transition:1s;
}


#{{uc_id}} .owl-dots {
overflow:hidden;
display:{{show_dots}} !important;
text-align:{{dot_alignment}};
}

#{{uc_id}} .owl-dot {
display:inline-block;
transition: all .3s;  
}

#{{uc_id}} .ue-listing-slider
{
  overflow:hidden;
}