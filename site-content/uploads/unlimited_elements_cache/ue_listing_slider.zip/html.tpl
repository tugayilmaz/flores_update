<div class="ue-listing-slider uc-dynamic-popup-grid"  style="direction:ltr;">
        <div class="uc_fbps_container">
            <div  class="owl-carousel uc-items-wrapper {{remote_parent.class}} {{uc_filtering_addclass}}" id="{{uc_id}}" {{remote_parent.attributes|raw}} data-custom-sethtml="true" {{uc_filtering_attributes|raw}}>
              
              {{put_items()}}
              
            </div>
        </div>
    </div>