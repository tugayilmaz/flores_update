<div class="uc_fbps_slide ue-grid-item" data-link="{{item.listing.link}}" data-postid="{{item.listing.id}}">
  {{putListingItemTemplate(item.listing.object,listing_templateid)}}
</div>