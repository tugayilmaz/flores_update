{{ ucfunc("put_docready_start") }}
		
    	
  var objCarousel = jQuery('#{{uc_id}}');
  
  		objCarousel.owlCarousel({
			loop:true,
				margin:0,
				nav: {{show_arrows}},
				items:1,
				dots:{{show_dots}},
                mouseDrag:{{mouse_drag}},
                touchDrag:{{touch_drag}},  
              	animateIn: '{{animate_in}}',
              	animateOut: '{{animate_out}}',
                autoplayTimeout: {{autoplay_timeout}},
                autoplayHoverPause: {{autoplay_hover_pause}},
                smartSpeed: {{transition_speed}},                                     
              	autoplay : {{autoplay}},
                enableAnimationOnDragSwipe: {{enable_animation_on_drag_swipe}},                 
				navText: ["<i class='{{left_arrow}}'></i>","<i class='{{right_arrow}}'></i>"]
		  });
  
		{{ucfunc("put_remote_parent_js","objCarousel")}}  
    	
      objCarousel.on("uc_ajax_sethtml",function(event, htmlItems, isAppend){

          objCarousel.trigger("replace.owl.carousel",htmlItems);
          objCarousel.trigger("refresh.owl.carousel");

      });
  		
  
{{ ucfunc("put_docready_end") }}