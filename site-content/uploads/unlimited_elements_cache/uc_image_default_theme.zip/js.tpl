jQuery(document).ready(function(){	
function {{uc_id}}_start(){
  
  var objGallery = jQuery("#{{uc_id}}");

  var api = objGallery.unitegallery({
    gallery_theme:"default",
    theme_enable_hidepanel_button:true,
    theme_hide_panel_under_width:{{hide_panel_under_width}},
    gallery_width:'{{gallery_width_nounit}}%',							
	gallery_height:{{gallery_height_nounit}},
	gallery_min_width: 100,					
	gallery_min_height: 300,				
	gallery_skin:"default",					
	gallery_images_preload_type:"minimal",	
												
	gallery_autoplay:{{gallery_autoplay}},	
	gallery_play_interval: {{gallery_play_interval}},				
	gallery_pause_on_mouseover: {{gallery_pause_on_mouseover}},			

	gallery_control_thumbs_mousewheel:{{gallery_control_thumbs_mousewheel}},	
	gallery_control_keyboard: {{gallery_control_keyboard}},				
	gallery_carousel:{{gallery_carousel}},						

	gallery_preserve_ratio: {{gallery_preserve_ratio}},				
	gallery_debug_errors:true,	
	slider_background_color:"{{slider_background_color}}",
	//slider options: 
	slider_video_autoplay: {{video_autoplay}},
	slider_scale_mode: "{{slider_scale_mode}}",	
	slider_scale_mode_media: "fill",			
	slider_scale_mode_fullscreen: "down",		
	slider_item_padding_top: 0,					
	slider_item_padding_bottom: 0,				
	slider_item_padding_left: 0,				
	slider_item_padding_right: 0,				

	slider_transition: "{{slider_transition}}",	
	slider_transition_speed:{{slider_transition_speed}},				
	slider_transition_easing: "easeInOutQuad",	

	slider_control_swipe:{{slider_control_swipe}},					
	slider_control_zoom:{{slider_control_zoom}},					
	slider_zoom_max_ratio: {{slider_zoom_max_ratio}},				
	slider_loader_type: {{slider_loader_type}},						
	slider_loader_color:"white",
	
	slider_enable_bullets: {{slider_enable_bullets}},				
	slider_bullets_skin: "",					
	slider_bullets_space_between: {{slider_bullets_space_between}},		
	slider_bullets_align_hor:"{{slider_bullets_align_hor}}",			
	slider_bullets_align_vert:"{{slider_bullets_align_vert}}",			
	slider_bullets_offset_hor:{{slider_bullets_offset_hor}},				 
	slider_bullets_offset_vert:{{slider_bullets_offset_vert}},				

	slider_enable_arrows: {{slider_enable_arrows}},					
	slider_arrows_skin: "",						
	slider_arrow_left_align_hor:"left",	  		
	slider_arrow_left_align_vert:"{{slider_arrow_align_vert}}", 		
	slider_arrow_left_offset_hor:{{arrow_horizontal_offset}},		  	
	slider_arrow_left_offset_vert:0,		  	
	slider_arrow_right_align_hor:"right",   	
	slider_arrow_right_align_vert:"{{slider_arrow_align_vert}}", 	
	slider_arrow_right_offset_hor:{{arrow_horizontal_offset}},	   		
	slider_arrow_right_offset_vert:0,
 
	slider_enable_progress_indicator: {{slider_enable_progress_indicator}},		 
	slider_progress_indicator_type: "pie",		 
	slider_progress_indicator_align_hor:"{{slider_progress_indicator_align_hor}}",  
	slider_progress_indicator_align_vert:"{{slider_progress_indicator_align_vert}}",  
	slider_progress_indicator_offset_hor:{{slider_progress_indicator_offset_hor}},	  
	slider_progress_indicator_offset_vert:{{slider_progress_indicator_offset_vert}},					slider_progressbar_color:"#ffffff",			 
	slider_progressbar_opacity: 0.6,			 
	slider_progressbar_line_width: 5,			 
	slider_progresspie_type_fill: false,		 
	slider_progresspie_color1: "#B5B5B5", 		 
	slider_progresspie_color2: "#ffffff",		  
	slider_progresspie_stroke_width: 6,			  
	slider_progresspie_width: 30,				 
	slider_progresspie_height:30,				 

	slider_enable_zoom_panel: {{slider_enable_zoom_panel}},				 
	slider_zoompanel_align_hor:"{{slider_zoompanel_align_hor}}",    		
	slider_zoompanel_align_vert:"{{slider_zoompanel_align_vert}}",     	 	
	slider_zoompanel_offset_hor:{{slider_zoompanel_offset_hor}},	       	 
	slider_zoompanel_offset_vert:{{slider_zoompanel_offset_vert}},	   	     

	slider_controls_always_on: true,		     
	slider_controls_appear_ontap: true,			 
	slider_controls_appear_duration: 300,		 
	slider_videoplay_button_type: "square",		  
	
					
	theme_enable_text_panel: {{slider_enable_text_panel}},			 
	slider_textpanel_always_on: {{text_panel_always_on}},			 
	slider_textpanel_text_valign:"middle",			
	slider_textpanel_padding_top:{{slider_textpanel_padding}},				
	slider_textpanel_padding_bottom:{{slider_textpanel_padding}},				
	slider_textpanel_padding_right: {{slider_textpanel_padding}},				
	slider_textpanel_padding_left: {{slider_textpanel_padding}},				
	slider_textpanel_height: null,					
	slider_textpanel_padding_title_description: 5,	 
	slider_textpanel_fade_duration: 200,			
	slider_textpanel_enable_title: {{slider_textpanel_enable_title}},			
	slider_textpanel_enable_description: true,		
	slider_textpanel_enable_bg: true,				
	slider_textpanel_bg_color:"{{slider_textpanel_bg_color}}",			
	slider_textpanel_bg_opacity: {{slider_textpanel_bg_opacity_nounit}},				
					
    strippanel_background_color:"{{strippanel_background_color}}",
                                    
	thumb_width:{{thumb_width_nounit}},								
	thumb_height:{{thumb_height_nounit}},							
	thumb_fixed_size:true,						

	thumb_border_effect:true,
	thumb_border_width: {{thumb_border_width_nounit}},						
	thumb_border_color: "{{thumb_border_color}}",				
	thumb_over_border_width: {{thumb_over_border_width_nounit}},					
	thumb_over_border_color: "{{thumb_over_border_color}}",			
	thumb_selected_border_width: {{thumb_selected_border_width_nounit}},
	thumb_selected_border_color: "{{thumb_selected_border_color}}",		

	thumb_round_corners_radius:{{thumb_round_corners_radius_nounit}},				

	thumb_color_overlay_effect: true,			
	thumb_overlay_color: "{{thumb_overlay_color}}",				
	thumb_overlay_opacity: {{thumb_overlay_opacity_nounit}},		
	thumb_overlay_reverse:{{thumb_overlay_reverse}},				
	thumb_image_overlay_effect: {{thumb_image_overlay_effect}},			
	thumb_image_overlay_type: "{{thumb_image_overlay_type}}",				
	thumb_transition_duration: 200,				
	thumb_transition_easing: "easeOutQuad",		
    strip_thumbs_align: "{{align_thumbs}}"                                
  });
  
  {{ucfunc("put_remote_parent_js","objGallery","unitegallery")}}  

   objGallery.on("uc_ajax_sethtml",function(event, htmlItems, isAppend){      	
        api.changeItems(htmlItems);         
   });

  
}if(jQuery("#{{uc_id}}").length) {{uc_id}}_start(); else
	jQuery( document ).on( 'elementor/popup/show', () => { if(jQuery("#{{uc_id}}").length) {{uc_id}}_start();});
});