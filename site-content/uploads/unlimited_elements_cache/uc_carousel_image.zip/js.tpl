jQuery(document).ready(function(){	
function {{uc_id}}_start(){

  var objWrapper = jQuery("#{{uc_id}}");
  
  var api = objWrapper.unitegallery({
    gallery_theme:"carousel",
    gallery_width:"{{gallery_width}}",
    tile_width: {{tile_width_nounit}},
    tile_height: {{tile_height_nounit}},
    tile_enable_outline: {{tile_enable_outline}},
    
    tile_as_link: {{tile_as_link}},
    tile_link_newpage: {{tile_link_newpage}},
    tile_enable_icons: {{tile_enable_icons}},
    tile_overlay_opacity: {{tile_overlay_opacity_nounit}},
    tile_overlay_color: "{{tile_overlay_color}}", 
    tile_background_color: "{{tile_background_color}}",
                       
    carousel_space_between_tiles: {{carousel_space_between_tiles_nounit}},		
	carousel_navigation_numtiles:{{carousel_navigation_numtiles}},			
	carousel_scroll_duration:{{carousel_scroll_duration}},			
	carousel_scroll_easing:"{{carousel_scroll_easing}}",	
	carousel_autoplay: {{carousel_autoplay}},				
	carousel_autoplay_timeout: {{carousel_autoplay_timeout}},		
	carousel_autoplay_direction: "{{carousel_autoplay_direction}}",	
	carousel_autoplay_pause_onhover: {{carousel_autoplay_pause_onhover}},
    
    theme_enable_navigation: {{theme_enable_navigation}},
    theme_navigation_position: "{{theme_navigation_position}}",
    theme_navigation_enable_play: {{navigation_enable_play}},
    theme_navigation_align: "center",		
	theme_navigation_margin: {{theme_navigation_margin_nounit}},			
	theme_space_between_arrows: {{theme_space_between_arrows_nounit}},
                                    
    tile_enable_textpanel:{{tile_enable_textpanel}},
    tile_textpanel_always_on: {{tile_textpanel_always_on}},
    tile_textpanel_appear_type: "{{tile_textpanel_appear_type}}",
    tile_textpanel_position:"{{tile_textpanel_position}}",
    tile_textpanel_padding_top:{{tile_textpanel_padding_nounit}},		 	
	tile_textpanel_padding_bottom:{{tile_textpanel_padding_nounit}},	 	
	tile_textpanel_padding_right: {{tile_textpanel_padding_nounit}},	 	
	tile_textpanel_padding_left: {{tile_textpanel_padding_nounit}},
    tile_textpanel_bg_color:"{{tile_textpanel_bg_color}}",
    tile_textpanel_bg_opacity:{{tile_textpanel_bg_opacity_nounit}},
    tile_textpanel_title_text_align:"{{tile_textpanel_title_text_align}}",
    tile_textpanel_title_color:"{{tile_textpanel_title_color}}",
                                    
                                    
    {% if tile_enable_border == "true" %}
        tile_enable_border:{{tile_enable_border}},
        tile_border_color:"{{tile_border_color}}",
        tile_border_width:{{tile_border_width_nounit}},
        tile_border_radius:{{tile_border_radius_nounit}}, 
        
    {% endif %}	

    {% if tile_enable_shadow == "true" %}
        tile_enable_shadow:{{tile_enable_shadow}},
        tile_shadow_color:"{{tile_shadow_color}}",
        tile_shadow_h:{{tile_shadow_h_nounit}},					
		tile_shadow_v:{{tile_shadow_v_nounit}},					
		tile_shadow_blur:{{tile_shadow_blur_nounit}},					
		tile_shadow_spread:{{tile_shadow_spread_nounit}},
     {% endif %}                               
    
    {% if tile_enable_image_effect == "true" %}
        tile_enable_image_effect:{{tile_enable_image_effect}},
        tile_image_effect_type: "{{tile_image_effect_type}}",
        tile_image_effect_reverse: {{tile_image_effect_reverse}},
    {% endif %}
                                    
    lightbox_type: "{{lightbox_type}}",
    lightbox_hide_arrows_onvideoplay: {{lightbox_hide_arrows_onvideoplay}},
    lightbox_arrows_position: "{{lightbox_arrows_position}}",                                
    lightbox_overlay_color:"{{lightbox_overlay_color}}",
    lightbox_overlay_opacity:{{lightbox_overlay_opacity_nounit}},	
    lightbox_show_numbers: {{lightbox_show_numbers}},
    lightbox_show_textpanel: {{lightbox_show_textpanel}},
    lightbox_slider_control_swipe:{{lightbox_slider_control_swipe}},
    lightbox_slider_control_zoom:{{lightbox_slider_control_zoom}},
    lightbox_textpanel_title_text_align:"{{lightbox_textpanel_title_text_align}}",                    
    lightbox_slider_image_border: {{lightbox_slider_image_border}},
    lightbox_slider_image_border_width: {{lightbox_slider_image_border_width_nounit}},
    lightbox_slider_image_border_color: "{{lightbox_slider_image_border_color}}",
    lightbox_slider_image_border_radius: {{lightbox_slider_image_border_radius_nounit}},

  });

   objWrapper.on("uc_ajax_sethtml",function(event, htmlItems, isAppend){      	
        api.changeItems(htmlItems);         
   });
 
  
}if(jQuery("#{{uc_id}}").length) {{uc_id}}_start(); else
	jQuery( document ).on( 'elementor/popup/show', () => { if(jQuery("#{{uc_id}}").length) {{uc_id}}_start();});
});